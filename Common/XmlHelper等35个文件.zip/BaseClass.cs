﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Web;
using System.Text;

namespace Common
{
    public class BaseClass
    {
        /*
         * <connectionStrings>
         *     <add name="connStr" connectionString="Data Source=.;Initial Catalog=.;uid=sa;password=123456;"/>
         * </connectionStrings>
         */
        private static readonly string StrConn = Decode(ConfigurationManager.ConnectionStrings["connStr"].ConnectionString);

        /// <summary>
        /// 解密
        /// </summary>
        private static string Decode(string str)
        {
            //string code = DesEncrypt.Decrypt(ConfigurationManager.ConnectionStrings["connStrCode"].ConnectionString);
            //str = DesEncrypt.Decrypt(str, code);
            //char[] c = str.ToCharArray();
            //Array.Reverse(c);
            //str = new string(c);
            //str = DesEncrypt.Decrypt(str);
            return str;
        }

        /// <summary>
        /// 获取数据表
        /// </summary>
        public static DataTable ReadTable(string sql, params SqlParameter[] sp)
        {
            using (SqlConnection conn = new SqlConnection(StrConn))
            {
                conn.Open();
                DataTable dt = new DataTable();
                SqlDataAdapter comm = new SqlDataAdapter(sql, conn);
                try
                {
                    if (sp != null)
                    {
                        SqlCommand sc = new SqlCommand(sql, conn);
                        sc.Parameters.Clear();
                        sc.Parameters.AddRange(sp);
                        comm.SelectCommand = sc;
                    }
                    comm.Fill(dt);
                    return dt;
                }
                catch (Exception ex)
                {
                    conn.Close();
                    return null;
                }
            }
        }

        /// <summary>
        /// 获取数据集
        /// </summary>
        public static DataSet ReadDataSet(string sql, string tableName = "", params SqlParameter[] sp)
        {
            using (SqlConnection conn = new SqlConnection(StrConn))
            {
                conn.Open();
                DataSet ds = new DataSet();
                SqlDataAdapter comm = new SqlDataAdapter(sql, conn);
                try
                {
                    if (sp != null)
                    {
                        SqlCommand sc = new SqlCommand(sql, conn);
                        sc.Parameters.Clear();
                        sc.Parameters.AddRange(sp);
                        comm.SelectCommand = sc;
                    }
                    if (!string.IsNullOrEmpty(tableName))
                    {
                        comm.Fill(ds, tableName);
                    }
                    else
                    {
                        comm.Fill(ds);
                    }
                    return ds;
                }
                catch (Exception ex)
                {
                    conn.Close();
                    return null;
                }
            }
        }

        /// <summary>
        /// 获取数据集
        /// </summary>
        public static DataSet ReadDataSet(string sql, params SqlParameter[] sp)
        {
            return ReadDataSet(sql, "", sp);
        }

        /// <summary>
        /// 执行CUD操作
        /// </summary>
        public static int ExecSql(string sql, params SqlParameter[] sp)
        {
            using (SqlConnection conn = new SqlConnection(StrConn))
            {
                conn.Open();
                SqlCommand comm = new SqlCommand(sql, conn);
                if (sp != null)
                {
                    comm.Parameters.Clear();
                    comm.Parameters.AddRange(sp);
                }
                try
                {
                    return comm.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    conn.Close();
                    return -1;
                }
            }
        }

        /// <summary>
        /// 获取数据Reader，需要手动关闭Reader
        /// </summary>
        public static IDataReader ExecReader(string sql, params SqlParameter[] sp)
        {
            SqlConnection conn = new SqlConnection(StrConn);
            conn.Open();
            SqlCommand comm = new SqlCommand(sql, conn);
            if (sp != null)
            {
                comm.Parameters.Clear();
                comm.Parameters.AddRange(sp);
            }
            try
            {
                return comm.ExecuteReader(CommandBehavior.CloseConnection);
            }
            catch (Exception ex)
            {
                conn.Close();
                return null;
            }
        }

        /// <summary>
        /// 获取单值
        /// </summary>
        public static object ReadScalar(string sql, params SqlParameter[] sp)
        {
            using (SqlConnection conn = new SqlConnection(StrConn))
            {
                conn.Open();
                SqlCommand comm = new SqlCommand(sql, conn);
                if (sp != null)
                {
                    comm.Parameters.Clear();
                    comm.Parameters.AddRange(sp);
                }
                try
                {
                    return comm.ExecuteScalar();
                }
                catch (Exception ex)
                {
                    conn.Close();
                    return null;
                }
            }
        }

        #region 带GO关键字处理
        public static int ExecuteSqlWithGoWithTransaction(string sql)
        {
            using (SqlConnection conn = new SqlConnection(StrConn))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                //创建事务
                SqlTransaction sqlTran = conn.BeginTransaction();
                cmd.Transaction = sqlTran;
                cmd.Connection = conn;
                try
                {
                    //注： 此处以 换行_后面带0到多个空格_再后面是go 来分割字符串  
                    String[] sqlArr = Regex.Split(sql.Trim(), "\r\n\\s*go", RegexOptions.IgnoreCase);
                    foreach (string strsql in sqlArr)
                    {
                        if (strsql.Trim().Length > 1 && strsql.Trim() != "\r\n")
                        {
                            cmd.CommandText = strsql;
                            return cmd.ExecuteNonQuery();
                        }
                    }
                    sqlTran.Commit();
                }
                catch (SqlException ex)
                {
                    sqlTran.Rollback();
                    throw new Exception(ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }
            return -1;
        }

        public static int ExecuteSqlWithGo(string sql)
        {
            using (SqlConnection conn = new SqlConnection(StrConn))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand { Connection = conn };
                try
                {
                    //注： 此处以 换行_后面带0到多个空格_再后面是go 来分割字符串  
                    String[] sqlArr = Regex.Split(sql.Trim(), "\r\n\\s*go", RegexOptions.IgnoreCase);
                    foreach (string strsql in sqlArr)
                    {
                        if (strsql.Trim().Length > 1 && strsql.Trim() != "\r\n")
                        {
                            cmd.CommandText = strsql;
                            return cmd.ExecuteNonQuery();
                        }
                    }
                }
                catch (SqlException ex)
                {
                    throw new Exception(ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }
            return -1;
        }
        #endregion

        #region by qiuweibin
        /// <summary>
        /// 构造查询语句
        /// </summary>
        /// <param name="BaseCmd">基础查询语句 参数用{0}{1}...{N}代替 不需要带引号 引号会自动添加</param>
        /// <param name="Params">参数 请按顺序填写，支持列表（将以《br》隔开）,支持表格（请放到参数最后，将以临时表形式传到数据库，表名为DataTable.TableName）</param>
        /// <returns>返回构造好的语句</returns>
        public static string BuildSql(string BaseCmd, params object[] Params)
        {
            List<DataTable> tables = new List<DataTable>();
            List<string> paramStrings = new List<string>();
            string sql_Start = "";
            string sql_Middle = "";
            string sql_End = "";
            string tempString;
            string[] tempArray;
            int index;
            foreach (object param in Params)
            {
                if (param is DataTable)
                {
                    tables.Add(param as DataTable);
                }
                else if (param is ICollection)
                {
                    if (param == null || (param as ICollection).Count == 0)
                    {
                        tempString = null;
                    }
                    else
                    {
                        tempArray = new string[(param as ICollection).Count];
                        index = 0;
                        foreach (object item in (param as ICollection))
                        {
                            tempArray[index] = item.ToString();
                            index++;
                        }
                        tempString = String.Join("<br>", tempArray);
                    }
                    paramStrings.Add(tempString);
                }
                else if (param is DateTime)
                {
                    paramStrings.Add((DateTime)param == default(DateTime) ? null : param.ToString());
                }
                else if (param is bool)
                {
                    paramStrings.Add((bool)param ? "1" : "0");
                }
                else
                {
                    paramStrings.Add(param == null ? null : param.ToString());
                }
            }

            foreach (DataTable table in tables)
            {
                TempTableStings ttStrings = TempTableHelper.GetStrings(table);
                sql_Start += "\r\n" + ttStrings.CreatString;
                sql_Start += "\r\n" + ttStrings.DataString;

                sql_End += "\r\n" + ttStrings.DropString;
            }

            index = 0;
            sql_Middle = BaseCmd;
            foreach (string paramString in paramStrings)
            {
                sql_Middle = sql_Middle.Replace("{" + index + "}", paramString == null ? "null" : "'" + paramString + "'");
                index++;
            }
            return sql_Start + "\r\n" + sql_Middle + "\r\n" + sql_End;
        }
        #endregion


        public static DataSet fnInsertSingleUser(DataTable v_dt, params string[] param)
        {
            try
            {
                SqlConnection cn = new SqlConnection(StrConn);
               // SqlConnection cn = new SqlConnection(connectionString);//connertionString链接数据库字符串
                SqlCommand cmd = cn.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = @"" + param[0];
                SqlParameter p = cmd.Parameters.AddWithValue("@addpack", v_dt);
                //参数可以随意增加

                SqlParameter pCode = cmd.Parameters.AddWithValue("@instruction_id", param[1]);





                  DataSet ds = new DataSet();
                   SqlDataAdapter da = new SqlDataAdapter(cmd);
                  da.Fill(ds);

            
                return ds;
            }
            catch (Exception ex)
            {
               throw ex;
            }
        }




    }
}
