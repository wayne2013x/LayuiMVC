﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using SqlSugar;
using System.Linq.Expressions;

namespace Common
{
    public class BaseLogic<T> where T : class, new()
    {
        /// <summary>
        /// 连接字符串
        /// </summary>
        readonly string StrConn = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;
        public SqlSugarClient Db;
        /// <summary>
        /// ORM实例
        /// </summary>
        public SimpleClient<T> CurrentDb { get { return new SimpleClient<T>(Db); } }
        /// <summary>
        /// 构造函数
        /// </summary>
        public BaseLogic()
        {
            Db = new SqlSugarClient(new ConnectionConfig()
            {
                ConnectionString = StrConn,
                DbType = DbType.SqlServer,
                InitKeyType = InitKeyType.Attribute,
                IsAutoCloseConnection = true,

            });
        }
        /// <summary>
        /// 根据id获取对象
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public virtual T Get(dynamic id)
        {
            return CurrentDb.GetById(id);
        }
        /// <summary>
        /// 获取所有数据
        /// </summary>
        /// <returns></returns>
        public virtual List<T> GetList()
        {
            return CurrentDb.GetList();
        }
        /// <summary>
        /// 获取分页数据
        /// </summary>
        /// <param name="where">linq查询</param>
        /// <param name="pageIndex">页码</param>
        /// <param name="pageSize">页数</param>
        /// <returns></returns>
        public virtual List<T> GetList(Expression<Func<T, bool>> where , int pageIndex, int pageSize)
        {

            return CurrentDb.GetPageList(where, new PageModel() { PageIndex = pageIndex, PageSize = pageSize });
        }
        /// <summary>
        /// 根据id删除对象
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public virtual bool Delete(dynamic id)
        {
            return CurrentDb.Delete(id);
        }
        /// <summary>
        /// 更新(为NULL的列不更新)
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public virtual bool Update(T obj)
        {
            return CurrentDb.AsUpdateable(obj).IgnoreColumns(ignoreAllNullColumns: true).ExecuteCommand() > 0;
        }
        /// <summary>
        /// 新增后返回id
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public virtual int Add(T obj)
        {
            var result = CurrentDb.InsertReturnIdentity(obj); 
            return result.ObjToInt();
        }
    }
}
