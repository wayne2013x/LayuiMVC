﻿using System;
using System.Reflection;
using System.Web;

namespace Common
{
    public class BaseAjax<T, Tbll> : CheckBlock where T : BaseModel, new() where Tbll : BaseLogic<T>, new()
    {
        public readonly Tbll bll = new Tbll();
        public override void ProcessRequest(HttpContext context)
        {
            string type = Request["type"];
            Invoke(type, this);
        }
        public virtual void GetAllList()
        {
            var list = bll.CurrentDb.GetList();
            string json = JsonHelper.ToJson(list);
            json = JsonHelperEx.GetLayuiTable(json, list.Count);
            Response.Write(json);
        }
        public virtual void GetList()
        {
            int index = Request["page"].ParseInt("1");
            int size = Request["limit"].ParseInt("10");
            var count = bll.GetList().Count; 
            var list = bll.GetList(t => t.id > 0 && t.del_f == "0", index, size);
            string json = JsonHelper.ToJson(list);
            json = JsonHelperEx.GetLayuiTable(json, count);
            Response.Write(json);
        }
        public virtual void Get()
        {
            int id = Request["id"].ParseInt();
            var list = bll.Get(id);
            string json = JsonHelper.ToJson(list);
            Response.Write(json);
        }
        public virtual void Add()
        {
            var result = false;
            try
            {
                T tobj = new T();
                PropertyInfo[] properties = tobj.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public);
                foreach (PropertyInfo item in properties)
                {
                    var nameVal = item.Name;
                    var typeVal = item.PropertyType;
                    var formVal = Request[nameVal] ?? null;
                    dynamic value = null;
                    if (formVal != null)
                    {
                        if (typeVal == typeof(int))
                            value = formVal.ParseInt();
                        else if (typeVal == typeof(float))
                            value = formVal.ParseFloat();
                        else if (typeVal == typeof(DateTime))
                            value = formVal.ParseDateTime();
                        else
                            value = formVal;
                        item.SetValue(tobj, value, null);
                    }
                }
                result = bll.Add(tobj) > 0;
            }
            catch(Exception ex)
            {
                //throw ex.Message;
            }
            string json = JsonHelperEx.GetAjaxMsg(result);
            Response.Write(json);
        }
        public virtual void Edit()
        {
            T tobj = new T();
            PropertyInfo[] properties = tobj.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public);
            foreach (PropertyInfo item in properties)
            {
                var nameVal = item.Name;
                var typeVal = item.PropertyType;
                var formVal = Request[nameVal] ?? null;
                dynamic value = null;
                if (formVal != null)
                {
                    if (typeVal == typeof(int))
                        value = formVal.ParseInt();
                    else if (typeVal == typeof(float))
                        value = formVal.ParseFloat();
                    else
                        value = formVal;
                    item.SetValue(tobj, value, null);
                }
            }
            var result = bll.Update(tobj);
            string json = JsonHelperEx.GetAjaxMsg(result);
            Response.Write(json);
        }
        public virtual void Delete()
        {
            int id = Request["id"].ParseInt();
            T tobj = new T();
            tobj.id = id;
            tobj.del_f = "1";
            //var result = bll.Delete(id);
            var result = bll.Update(tobj);
            string json = JsonHelperEx.GetAjaxMsg(result);
            Response.Write(json);
        }
    }
}
