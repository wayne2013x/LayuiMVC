﻿using System.Data;
using System.Web;

namespace Common
{
    /// <summary>
    /// 获取当前登录用户的信息
    /// </summary>
    public class UserInfoUtil
    {
        private UserInfoUtil() { }

        public static string GetUserSalt()
        {
            string userSalt = CookiesHelper.GetCookieValue("UserSalt");
            try
            {
                userSalt = DesEncrypt.Decrypt(userSalt);
            }
            catch
            {
                userSalt = "";
            }
            return userSalt;
        }

        public static string GetUserId()
        {
            string userId = CookiesHelper.GetCookieValue("UserId");
            try
            {
                userId = DesEncrypt.Decrypt(userId);
            }
            catch
            {
                userId = "";
            }
            return userId;
        }

        public static string GetUserNo()
        {
            string sql = string.Format("SELECT User_No FROM UserInfo WHERE Id = '{0}';", GetUserId());
            object obj = BaseClass.ReadScalar(sql);
            if (obj != null)
            {
                return obj.ToString();
            }
            return "";
        }

        public static string GetUserName()
        {
            string sql = string.Format("SELECT User_Name FROM UserInfo WHERE Id = '{0}';", GetUserId());
            object obj = BaseClass.ReadScalar(sql);
            if (obj != null)
            {
                return obj.ToString();
            }
            return "";
        }

        //public static string GetUserRealName()
        //{
        //    string sql = string.Format("SELECT UserRealName FROM UserInfo WHERE Id = '{0}';", GetUserId());
        //    object obj = BaseClass.ReadScalar(sql);
        //    if (obj != null)
        //    {
        //        return obj.ToString();
        //    }
        //    return "";
        //}

        public static string GetUserRole()
        {
            string sql = string.Format("SELECT RoleId FROM UserRole WHERE UserId = '{0}';", GetUserId());
            DataTable dt = BaseClass.ReadTable(sql);
            if (dt != null)
            {
                string roleList = "";
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    DataRow row = dt.Rows[i];
                    roleList += row["RoleId"] + ",";
                }
                roleList = roleList.TrimEnd(',');
                return roleList;
            }
            return "";
        }

        public static string GetUserRoleName()
        {
            string sql = string.Format("SELECT RoleName FROM RoleInfo WHERE Id IN ({0});", GetUserRole());
            DataTable dt = BaseClass.ReadTable(sql);
            if (dt != null)
            {
                string roleList = "";
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    DataRow row = dt.Rows[i];
                    roleList += row["RoleName"] + ",";
                }
                roleList = roleList.TrimEnd(',');
                return roleList;
            }
            return "";
        }

        public static string GetUserDept()
        {
            string sql = string.Format("SELECT department FROM UserInfo WHERE Id = '{0}';", GetUserId());
            object obj = BaseClass.ReadScalar(sql);
            if (obj != null)
            {
                return obj.ToString();
            }
            return "";
        }

        public static string GetUserPos()
        {
            string sql = string.Format("SELECT position FROM UserInfo WHERE Id = '{0}';", GetUserId());
            object obj = BaseClass.ReadScalar(sql);
            if (obj != null)
            {
                return obj.ToString();
            }
            return "";
        }

        public static string GetUserPortrait()
        {
            string sql = string.Format("SELECT Portrait FROM UserInfo WHERE Id = '{0}';", GetUserId());
            object obj = BaseClass.ReadScalar(sql);
            if (obj != null && !string.IsNullOrEmpty(obj.ToString()))
            {
                return "/Upload/UserInfo/" + obj;
            }
            return "/Images/用户名.png";
        }

        public static bool SetSalt(int id, string salt)
        {
            string sql = string.Format("UPDATE UserInfo SET Salt = '{0}' WHERE Id = '{1}';", salt, id);
            int result = BaseClass.ExecSql(sql);
            return result > 0;
        }

        public static bool GetSalt(int id, string salt)
        {
            string sql = string.Format("SELECT Salt FROM UserInfo WHERE Salt = '{0}' AND Id = '{1}';", salt, id);
            DataTable dt = BaseClass.ReadTable(sql);
            if (dt != null && dt.Rows.Count > 0)
            {
                return true;
            }
            return false;
        }

        public static bool HasPermission(int userId, string menuLink)
        {
            if (userId > 0)
            {
                string sql = string.Format("SELECT RoleId FROM UserRole WHERE UserId = '{0}';", userId);
                DataSet ds = BaseClass.ReadDataSet(sql);
                string roleList = "";
                if (ds != null && ds.Tables.Count > 0)
                {
                    DataTable dt = ds.Tables[0];
                    if (dt != null)
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            DataRow row = dt.Rows[i];
                            roleList += row["RoleId"] + ",";
                        }
                        roleList = roleList.TrimEnd(',');

                        string table = "RolePage";
                        string field = "ISNULL(COUNT(1), 0)";
                        string where = string.Format(" AND [RoleId] IN ({0})", roleList);
                        where += string.Format(" AND MenuId = ( SELECT Id FROM Menu WHERE LinkAddress = '{0}')", menuLink);
                        DataSet rbDs = DbCommonHelper.Select(table, field, where);
                        if (rbDs != null && rbDs.Tables.Count > 0 &&
                            rbDs.Tables[0] != null && rbDs.Tables[0].Rows.Count > 0)
                        {
                            DataRow row = rbDs.Tables[0].Rows[0];
                            object count = row[0];
                            if (count != null && count.ToString() != "0")
                            {
                                return true;
                            }
                        }
                    }
                }
            }
            return false;
        }

        public static bool HasPagePermission(int userId, string root, string page)
        {
            if (userId > 0)
            {
                string sql = string.Format("SELECT RoleId FROM UserRole WHERE UserId = '{0}';", userId);
                DataSet ds = BaseClass.ReadDataSet(sql);
                string roleList = "";
                if (ds != null && ds.Tables.Count > 0)
                {
                    DataTable dt = ds.Tables[0];
                    if (dt != null)
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            DataRow row = dt.Rows[i];
                            roleList += row["RoleId"] + ",";
                        }
                        roleList = roleList.TrimEnd(',');

                        //根据路径获取到当前访问子页面的父级页面
                        object o = BaseClass.ReadScalar("SELECT TOP 1 Id, 0 FROM [Menu] WHERE [RootLink] = '" + root + "';");
                        if (o == null) return false;
                        string pMenuId = o.ToString();

                        string table = "RolePage rp";
                        table += " LEFT JOIN [Page] p ON p.[Id] = rp.[PageId]";
                        string field = "ISNULL(COUNT(rp.Id), 0)";
                        string where = string.Format(" AND [RoleId] IN ({0})", roleList);
                        where += string.Format(" AND rp.[MenuId] = '{0}'", pMenuId);
                        where += string.Format(" AND p.[LinkAddress] = '{0}'", page);
                        DataSet rbDs = DbCommonHelper.Select(table, field, where);
                        if (rbDs != null && rbDs.Tables.Count > 0 &&
                            rbDs.Tables[0] != null && rbDs.Tables[0].Rows.Count > 0)
                        {
                            DataRow row = rbDs.Tables[0].Rows[0];
                            object count = row[0];
                            if (count != null && count.ToString() != "0")
                            {
                                return true;
                            }
                        }
                    }
                }
            }
            return false;
        }
    }
}
