﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SqlSugar;

namespace Common
{
    public class BaseModel
    {
        public BaseModel()
        {
            create_on = DateTime.Now.ToString("yyyy-MM-dd HH:mm");
            del_f = "0";
        }
        [SugarColumn(IsPrimaryKey = true, IsIdentity = true)]
        public int id { get; set; }
        public string create_on {get;set;}

        public string del_f { get; set; }
    }
}
